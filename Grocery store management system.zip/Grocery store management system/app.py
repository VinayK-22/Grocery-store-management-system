from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

# database connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Vinayk@2002",
    database="vks_db"
)
cursor = conn.cursor()

@app.route('/')
def index():
    # fetch products with category names
    cursor.execute("""
        SELECT p.id, p.name, c.name, p.price, p.stock
        FROM products p
        JOIN categories c ON p.category_id = c.id
    """)
    products = cursor.fetchall()

    # fetch categories for dropdown
    cursor.execute("SELECT * FROM categories")
    categories = cursor.fetchall()

    return render_template('index.html', products=products, categories=categories)

@app.route('/add', methods=['POST'])
def add_product():
    name = request.form['name']
    category = request.form['category']
    price = request.form['price']
    stock = request.form['stock']
    cursor.execute(
        "INSERT INTO products (name, category_id, price, stock) VALUES (%s, %s, %s, %s)",
        (name, category, price, stock)
    )
    conn.commit()
    return redirect('/')

# 🔹 ADD THIS ROUTE BELOW (for delete)
@app.route('/delete/<int:id>')
def delete_product(id):
    cursor.execute("DELETE FROM products WHERE id = %s", (id,))
    conn.commit()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
